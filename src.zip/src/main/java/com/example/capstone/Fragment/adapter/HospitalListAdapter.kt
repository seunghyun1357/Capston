package com.example.capstone.Fragment.adapter

import android.speech.tts.TextToSpeech
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.capstone.R
import com.example.capstone.data.Hospital

class HospitalListAdapter(private val dataList: MutableList<Hospital>, private val selectList: (Hospital) -> Unit) :
    RecyclerView.Adapter<HospitalListAdapter.ViewHolder>(), TextToSpeech.OnInitListener  {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textName : TextView = itemView.findViewById(R.id.text_name)
        val textAddress: TextView = itemView.findViewById(R.id.text_address)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.hospital_item, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val hospital = dataList[position]

        holder.itemView.setOnClickListener {
            selectList(hospital)
        }

        holder.textName.text = hospital.name
        holder.textAddress.text = hospital.address
    }

    override fun onInit(p0: Int) {
    }

}